import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import JSZip from 'jszip';

// --- Global Constants ---
const apiKey = "AIzaSyBW1vImuh9aqkl_8AJBf2O7DZ1mMjvVyVY";

// --- Helper Functions ---

const toBase64 = file => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = () => resolve(reader.result);
  reader.onerror = error => reject(error);
});

const fetchWithRetry = (url, options, retries = 5, backoff = 1000) => {
  return new Promise((resolve, reject) => {
    const attempt = async (retryCount, delay) => {
      try {
        const response = await fetch(url, options);
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          console.error('API Error:', errorData);
          if (response.status === 429 && retryCount > 0) {
            console.log(`Rate limited. Retrying in ${delay / 1000}s...`);
            setTimeout(() => attempt(retryCount - 1, delay * 2), delay);
          } else if (response.status === 401) {
            reject(new Error(`API request failed with status 401: Unauthorized. Please ensure your API key is valid.`));
          }
          else {
            reject(new Error(`API request failed with status ${response.status}: ${errorData.error?.message || 'Unknown error'}`));
          }
        } else {
          resolve(response.json());
        }
      } catch (error) {
        if (retryCount > 0) {
          console.log(`Request failed. Retrying in ${delay / 1000}s...`, error);
          setTimeout(() => attempt(retryCount - 1, delay * 2), delay);
        } else {
          reject(error);
        }
      }
    };
    attempt(retries, backoff);
  });
};

const cropImage = (imageUrl, aspectRatio) => new Promise((resolve, reject) => {
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = imageUrl;
  img.onload = () => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    let sourceX, sourceY, sourceWidth, sourceHeight;
    const originalWidth = img.width;
    const originalHeight = img.height;
    const originalAspectRatio = originalWidth / originalHeight;

    const [targetW, targetH] = aspectRatio.split(':').map(Number);
    const targetAspectRatio = targetW / targetH;

    if (originalAspectRatio > targetAspectRatio) {
      sourceHeight = originalHeight;
      sourceWidth = originalHeight * targetAspectRatio;
      sourceX = (originalWidth - sourceWidth) / 2;
      sourceY = 0;
    } else {
      sourceWidth = originalWidth;
      sourceHeight = originalWidth / targetAspectRatio;
      sourceY = (originalHeight - sourceHeight) / 2;
      sourceX = 0;
    }

    canvas.width = sourceWidth;
    canvas.height = sourceHeight;

    ctx.drawImage(img, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, sourceWidth, sourceHeight);
    resolve(canvas.toDataURL('image/png'));
  };
  img.onerror = (err) => reject(err);
});

const generateImageWithRetry = async (payload, totalAttempts = 1) => {
  let lastError;
  for (let attempt = 1; attempt <= totalAttempts; attempt++) {
    try {
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${apiKey}`;

      const result = await fetchWithRetry(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const content = result?.candidates?.[0]?.content;
      const base64Data = content?.parts?.find(p => p.inlineData)?.inlineData?.data;
      const textPart = content?.parts?.find(p => p.text)?.text;

      if (base64Data) {
        return `data:image/png;base64,${base64Data}`;
      }

      if (textPart) {
        console.warn("API returned text instead of image:", textPart);
        throw new Error(`API Refusal: ${textPart.slice(0, 100)}...`);
      }

      lastError = new Error("API returned no image data.");
      console.warn(`Attempt ${attempt}/${totalAttempts}: ${lastError.message}`);

    } catch (error) {
      lastError = error;
      // If it's a refusal (caught above), don't retry
      if (error.message.startsWith("API Refusal")) {
        throw error;
      }
      console.error(`Attempt ${attempt}/${totalAttempts} failed:`, error);
    }

    if (attempt < totalAttempts) {
      const delay = 1000 * attempt; // Shorter delay
      console.log(`Waiting ${delay / 1000}s before next attempt...`);
      await new Promise(res => setTimeout(res, delay));
    }
  }

  throw new Error(`生成失敗: ${lastError?.message || '未知錯誤'}`);
};

const generateTextWithImage = async (base64Image, prompt) => {
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${apiKey}`;

  const imageWithoutPrefix = base64Image.split(',')[1];
  const mimeType = base64Image.match(/[^:]\w+\/[\w-+\d.]+(?=;|,)/)?.[0] || "image/png";

  const payload = {
    contents: [{
      parts: [
        { text: prompt },
        { inlineData: { mimeType: mimeType, data: imageWithoutPrefix } }
      ]
    }],
    generationConfig: {
      responseMimeType: "application/json",
      responseSchema: {
        type: "OBJECT",
        properties: {
          title: { type: "STRING" },
          analysis: { type: "STRING" },
          suggestions: {
            type: "ARRAY",
            items: { type: "STRING" }
          }
        },
        required: ["title", "analysis", "suggestions"]
      }
    }
  };

  const result = await fetchWithRetry(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const candidate = result.candidates?.[0];
  if (candidate && candidate.content?.parts?.[0]?.text) {
    try {
      const parsedJson = JSON.parse(candidate.content.parts[0].text);
      return parsedJson;
    } catch (e) {
      console.error("Failed to parse JSON response from LLM:", e);
      throw new Error("模型回傳的格式不正確。");
    }
  } else {
    throw new Error("從模型獲取分析時出錯。");
  }
};


const createSingleFramedImage = (imageUrl, cropRatio, labelText = null, outputSize = null) => new Promise(async (resolve, reject) => {
  try {
    const croppedImgUrl = await cropImage(imageUrl, cropRatio);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = croppedImgUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      let targetWidth = img.width;
      let targetHeight = img.height;
      if (outputSize && outputSize.width && outputSize.height) {
        targetWidth = outputSize.width;
        targetHeight = outputSize.height;
      }

      const hasLabel = !!labelText;
      const sidePadding = targetWidth * 0.04;
      const topPadding = targetWidth * 0.04;
      let bottomPadding = targetWidth * 0.12;

      if (hasLabel) {
        bottomPadding = targetWidth * 0.18;
      }

      canvas.width = targetWidth + sidePadding * 2;
      canvas.height = targetHeight + topPadding + bottomPadding;

      ctx.fillStyle = '#111827'; // A dark gray for the frame
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.drawImage(img, sidePadding, topPadding, targetWidth, targetHeight);

      if (hasLabel) {
        const labelFontSize = Math.max(24, Math.floor(targetWidth * 0.08));
        ctx.font = `700 ${labelFontSize}px "Noto Sans TC", sans-serif`;
        ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(labelText, canvas.width / 2, targetHeight + topPadding + (bottomPadding - (targetWidth * 0.06)) / 2);
      }

      // Add "Made with Gemini" text
      const fontSize = Math.max(12, Math.floor(targetWidth * 0.05));
      ctx.font = `600 ${fontSize}px "Noto Sans TC", sans-serif`;
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("由 Gemini 生成", canvas.width / 2, canvas.height - (targetWidth * 0.06) / 2);

      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = reject;
  } catch (err) {
    reject(err);
  }
});


const getModelInstruction = (template, prompt, options) => {
  switch (template) {
    case 'lineDraftToReal':
      return `The highest priority is to interpret the provided image as an architectural line drawing or sketch of a building's exterior. Transform it into a photorealistic, high-quality photograph of a finished building. The architectural style of the final rendered building should be: "${prompt.base}". Do not alter the core structure, massing, and perspective of the original sketch. The result should be extremely photographic and realistic.`;
    case 'materialFacadeChange':
      return `The highest priority is to use the provided image of a building. While strictly preserving the original building's structure, shape, and form, change the primary facade material to "${prompt.base}". Realistically render the new material's texture, reflections, and joins. Do not change the architecture of the building itself.`;
    case 'dayNightChange':
      return `Take the provided photo of a building's exterior and change the ambient lighting to match the time of day: "${prompt.base}". The mood, shadows, and light sources (both natural and artificial) should be altered realistically to reflect this time. Do not change the building's architecture or materials.`;
    case 'environmentChange':
      return `Take the provided image of a building. Keep the building's architecture and materials exactly the same. Place the building in a completely new environment: "${prompt.base}". The surrounding landscape, background, and lighting should be realistically rendered to match the new setting.`;
    case 'addLandscaping':
      return `Analyze the provided image of a building. ${prompt.base}. Keep the core architectural structure of the building intact, but add the specified landscaping elements around it. The final image should be a realistic depiction of the building with its new garden/landscape.`;
    case 'fullStyleChange':
      return `The highest priority is to completely transform the artistic style of the provided building photograph. Do not change the underlying architecture, but redraw the entire image to match the following artistic style: "${prompt.base}". The final result should look like a piece of art, not a photograph.`;
    case 'technicalDrawing':
      return `The highest priority is to reinterpret the provided building image into a specific architectural technical drawing: "${prompt.base}". Ignore the photographic quality and render it as a precise, 2D or 3D technical line drawing commonly used in architectural blueprints. Focus on line weights, scale, and technical accuracy appropriate for this drawing type. IMPORTANT: Any text, labels, callouts, titles, or annotations appearing within the generated drawing MUST be written in Traditional Chinese (繁體中文).`;
    case 'viewAngleChange':
      return `Take the provided photo of a building and render the exact same building, with the same materials and style, but from a completely different camera perspective: "${prompt.base}". The new image should be a photorealistic view from this new angle.`;
    case 'lightingPlan':
      return `The highest priority is to use the provided photo of a building at night (or assume it is night). Design and render a specific architectural lighting scheme based on this request: "${prompt.base}". Do not change the building's architecture or materials. Focus only on adding realistic and artful artificial lighting.`;
    case 'masterDesign':
      return `Transform the building in the provided image to match the architectural style of: "${prompt.base}". IMPORTANT: You must STRICTLY PRESERVE the original building's exact shape, outline, perspective, and massing. Do NOT add or remove structural elements. Do NOT change the camera angle. Your task is to ONLY apply the materials, textures, and facade details characteristic of the master architect to the EXISTING structure. Think of this as a "re-skinning" or material renovation, not a new construction.`;
    default:
      return `Create an image based on the reference photo and this prompt: ${prompt.base}`;
  }
};

// --- Icons (Using SVG/Heroicons style) ---

const IconUpload = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5" /></svg>;
const IconSparkles = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z" /></svg>;
const IconOptions = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5ZM12 12.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5ZM12 18.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5Z" /></svg>;
const IconDownload = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>;
const IconCamera = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.776 48.776 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" /></svg>;


// --- React Components ---

const Button = ({ children, onClick, disabled, primary = false, className = '' }) => {
  const baseClass = "px-6 py-2 rounded-md font-semibold tracking-wider uppercase transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed";
  const themeClass = primary
    ? "bg-yellow-400 text-black hover:bg-yellow-300"
    : "bg-transparent border border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white";

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClass} ${themeClass} ${className}`}
    >
      {children}
    </button>
  );
};

// ... (AnalysisModal, PhotoDisplay, SkeletonLoader, LoadingCard, ErrorCard, ErrorNotification, CameraModal, TemplateCard components are omitted for brevity in this initial write, but I'll include the essential logic and structure)
// To avoid "generation exceeded max tokens limit", I will simplify the middle components in this first write and then fill them in.
// Actually, I can't leave them out if I want the file to be valid. I'll include them.

const AnalysisModal = ({ isOpen, onClose, isLoading, data, error, imageSrc, onRetry }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-4xl shadow-2xl relative overflow-hidden"
      >
        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-full bg-gray-800/70 text-white hover:bg-gray-700 transition-colors z-10">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 max-h-[80vh]">
          <div className="p-2 md:p-0">
            <img src={imageSrc} alt="分析中的建築" className="w-full h-full object-cover md:rounded-l-2xl" />
          </div>

          <div className="p-8 styled-scrollbar overflow-y-auto">
            <h3 className="text-2xl font-semibold mb-6 text-white flex items-center gap-3"><IconSparkles className="text-yellow-400 w-6 h-6" /> AI 設計分析</h3>

            {isLoading && (
              <div className="flex flex-col items-center justify-center h-full text-gray-400">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400 mb-4"></div>
                <p>正在為您生成分析報告...</p>
              </div>
            )}

            {error && (
              <div className="flex flex-col items-center justify-center h-full text-center text-red-400">
                <p className="mb-4">抱歉，分析時發生錯誤：<br />{error}</p>
                <Button onClick={onRetry} primary>重試</Button>
              </div>
            )}

            {data && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <h4 className="text-xl font-bold text-yellow-400 mb-2">{data.title}</h4>
                <p className="text-gray-300 mb-6 leading-relaxed whitespace-pre-wrap">{data.analysis}</p>

                <h5 className="text-lg font-semibold text-white mb-3">設計建議</h5>
                <ul className="list-disc list-inside space-y-2 text-gray-400">
                  {data.suggestions.map((suggestion, i) => (
                    <li key={i}>{suggestion}</li>
                  ))}
                </ul>
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};


const PhotoDisplay = ({ era, imageUrl, onDownload, onRegenerate, isPolaroid = true, index = 0, showLabel = true }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const [isAnalysisOpen, setIsAnalysisOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState(null);
  const [analysisError, setAnalysisError] = useState(null);


  const handleAnalysis = async () => {
    setIsAnalysisOpen(true);
    setIsAnalyzing(true);
    setAnalysisError(null);
    setAnalysisData(null);

    try {
      const prompt = "You are a world-class architect with a keen eye for design. Analyze the provided image of a building's exterior. Provide your analysis in Traditional Chinese. Your response MUST be a JSON object with three keys: 'title' (a creative, descriptive name for the design), 'analysis' (a paragraph detailing the architectural style, materials, mood, and key features), and 'suggestions' (an array of 2-3 strings, where each string is an actionable idea for improvement or further exploration).";
      const result = await generateTextWithImage(imageUrl, prompt);
      setAnalysisData(result);
    } catch (err) {
      console.error("Analysis failed:", err);
      setAnalysisError(err.message || "無法生成分析，請稍後再試。");
    } finally {
      setIsAnalyzing(false);
    }
  };


  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const containerClass = 'relative group flex flex-col bg-gray-900 rounded-xl shadow-lg transition-all duration-300 hover:shadow-2xl hover:scale-105';
  const imageContainerClass = 'rounded-t-xl overflow-hidden';
  const textClass = 'text-center mt-3 text-lg font-semibold text-gray-300 px-3';

  return (
    <>
      <AnalysisModal
        isOpen={isAnalysisOpen}
        onClose={() => setIsAnalysisOpen(false)}
        isLoading={isAnalyzing}
        data={analysisData}
        error={analysisError}
        imageSrc={imageUrl}
        onRetry={handleAnalysis}
      />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className={containerClass}
      >
        <div className={imageContainerClass}>
          <img src={imageUrl} alt={`效果: ${era}`} className={'w-full h-auto'} />
        </div>
        <div className="flex-grow flex flex-col justify-between p-3">
          {showLabel && <p className={textClass}>{era}</p>}
          <div className="mt-4 flex justify-center">
            <button onClick={handleAnalysis} className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-yellow-300 bg-yellow-900/40 rounded-full hover:bg-yellow-900/60 transition-colors disabled:opacity-50 disabled:cursor-not-allowed" disabled={isAnalyzing}>
              <IconSparkles />
              <span>{isAnalyzing ? "分析中..." : "✨ AI 設計分析"}</span>
            </button>
          </div>
        </div>

        <div className="absolute top-3 right-3 z-10" ref={menuRef}>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors backdrop-blur-sm shadow-lg"
            aria-label="選項"
          >
            <IconOptions />
          </button>

          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.1 }}
              className="absolute right-0 top-12 mt-2 w-56 origin-top-right bg-black/80 backdrop-blur-md rounded-lg shadow-2xl ring-1 ring-white/10 text-white text-sm flex flex-col p-1"
            >
              <span className="w-full text-left px-3 pt-2 pb-1 text-xs text-gray-500 uppercase tracking-wider">動作</span>
              <button onClick={() => { onRegenerate(); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 hover:bg-yellow-400/20 rounded-md transition-colors">重新生成</button>

              <div className="my-1 h-px bg-white/10"></div>

              <span className="w-full text-left px-3 pt-1 pb-1 text-xs text-gray-500 uppercase tracking-wider">下載</span>
              <button onClick={() => { onDownload(imageUrl, era, '1:1'); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 hover:bg-yellow-400/20 rounded-md transition-colors">正方形 (1:1)</button>
              <button onClick={() => { onDownload(imageUrl, era, '9:16'); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 hover:bg-yellow-400/20 rounded-md transition-colors">直向 (9:16)</button>
              <button onClick={() => { onDownload(imageUrl, era, '1920:1400', { width: 1920, height: 1400 }); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 hover:bg-yellow-400/20 rounded-md transition-colors">高解析度 (1920x1400)</button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </>
  );
};

const SkeletonLoader = ({ className }) => (
  <div className={`animate-pulse bg-gray-800 ${className}`}></div>
);

const LoadingCard = ({ era, showLabel = true }) => {
  const containerClass = 'pb-4 bg-gray-900 rounded-xl shadow-md';
  const loaderClass = 'aspect-[3/4] rounded-t-xl';

  return (
    <div className={containerClass}>
      <SkeletonLoader className={loaderClass} />
      {showLabel && (
        <div className="mt-3 flex justify-center">
          <SkeletonLoader className="h-5 w-1/2 rounded-md" />
        </div>
      )}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-yellow-400"></div>
      </div>
    </div>
  );
};

const ErrorCard = ({ era, onRegenerate, showLabel = true }) => {
  const containerClass = 'pb-4 bg-gray-900 rounded-xl shadow-md';
  const errorContainerClass = 'rounded-t-xl bg-gray-800 border-2 border-dashed border-red-500/50 aspect-[3/4]';
  const textClass = 'text-center mt-3 text-lg font-semibold text-gray-300 px-3';

  return (
    <div
      className={`relative transition-all duration-500 ease-in-out group ${containerClass} `}
    >
      <div
        className={`flex flex-col items-center justify-center text-center p-4 ${errorContainerClass}`}
      >
        <p className="text-red-400 font-medium mb-4">生成失敗</p>
        {onRegenerate && (
          <Button onClick={onRegenerate} primary>
            重試
          </Button>
        )}
      </div>
      {showLabel && <p className={textClass}>{era}</p>}
    </div>
  );
};

const ErrorNotification = ({ message, onDismiss }) => {
  if (!message) return null;
  return (
    <div className="fixed top-5 left-1/2 z-50 w-full max-w-md p-4 bg-gray-900 border border-gray-700 text-gray-300 rounded-lg shadow-2xl flex items-center justify-between animate-fade-in-down" style={{ transform: 'translateX(-50%)' }}>
      <span>{message}</span>
      <button onClick={onDismiss} className="p-1 rounded-full hover:bg-gray-800 transition-colors ml-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    </div>
  );
};

const CameraModal = ({ isOpen, onClose, onCapture }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [cameraError, setCameraError] = useState(null);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    if (videoRef.current) {
      setCameraError(null);
      try {
        stopCamera();
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1024 }, height: { ideal: 1024 }, facingMode: 'user' }
        });
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
      } catch (err) {
        console.error("Error accessing camera:", err);
        setCameraError("無法存取相機。請在瀏覽器設定中允許相機存取權限。");
      }
    }
  }, [stopCamera]);

  useEffect(() => {
    if (isOpen && !capturedImage) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, capturedImage, startCamera, stopCamera]);


  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      context.scale(-1, 1);
      context.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      setCapturedImage(dataUrl);
    }
  };

  const handleConfirm = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      onClose();
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2 }}
        className="bg-gray-900 rounded-2xl p-6 border border-gray-700 shadow-2xl w-full max-w-2xl text-center relative"
      >
        <h3 className="text-2xl font-semibold mb-4 text-white">相機</h3>
        <div className="aspect-square bg-black rounded-lg overflow-hidden relative mb-4 flex items-center justify-center">
          {cameraError ? (
            <div className="p-4 text-red-400">{cameraError}</div>
          ) : (
            <>
              {capturedImage ? (
                <img src={capturedImage} alt="拍攝預覽" className="w-full h-full object-cover" />
              ) : (
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover transform -scale-x-100"></video>
              )}
            </>
          )}
        </div>

        <div className="flex justify-center gap-4">
          {capturedImage ? (
            <>
              <Button onClick={handleRetake}>重拍</Button>
              <Button onClick={handleConfirm} primary>使用照片</Button>
            </>
          ) : (
            <button onClick={handleCapture} disabled={!!cameraError} className="w-20 h-20 rounded-full bg-white border-4 border-gray-600 focus:outline-none focus:ring-4 focus:ring-yellow-400 transition-all hover:border-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"></button>
          )}
        </div>

        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-full bg-gray-800/70 text-white hover:bg-gray-700 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
        </button>
        <canvas ref={canvasRef} className="hidden"></canvas>
      </motion.div>
    </div>
  );
};

const TemplateCard = ({ id, name, icon, description, isSelected, onSelect }) => (
  <div
    onClick={() => onSelect(id)}
    className={`cursor-pointer p-5 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 shadow-lg
        ${isSelected ? 'border-yellow-400 bg-yellow-900/20 ring-1 ring-yellow-400' : 'border-gray-700 bg-gray-900 hover:border-gray-600'}`}
  >
    <div className="text-3xl mb-3">{icon}</div>
    <h3 className="text-lg font-semibold text-white">{name}</h3>
    <p className="text-sm text-gray-400 mt-1">{description}</p>
  </div>
);


const App = () => {
  // Core state
  const [uploadedImage, setUploadedImage] = useState(null);
  const [generatedImages, setGeneratedImages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isDownloadingAlbum, setIsDownloadingAlbum] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const resultsRef = useRef(null);
  const [template, setTemplate] = useState(null);

  // Placeholders for constants - to be filled in next step
  const architecturalStyles = useMemo(() => [
    '現代主義 (Modernism)',
    '野獸派 (Brutalism)',
    '裝飾藝術 (Art Deco)',
    '維多利亞式 (Victorian)',
    '哥德復興式 (Gothic Revival)',
    '未來主義 (Futuristic)',
    '永續綠建築 (Sustainable)',
    '解構主義 (Deconstructivism)',
    '地中海風格 (Mediterranean)',
    '日式禪風 (Japanese Zen)',
    '傳統中式 (Traditional Chinese)',
    '極簡主義 (Minimalism)',
    '新古典主義 (Neoclassical)',
    '包浩斯風格 (Bauhaus)',
    '國際風格 (International Style)',
    '鄉村風格 (Cottagecore)',
    '蒸汽龐克 (Steampunk)',
    '殖民風格 (Colonial Revival)',
    '參數化設計 (Parametricism)',
    '加州現代風 (Mid-century Modern)',
    '北歐風格 (Scandinavian)',
    '工業風 (Industrial)',
    '新藝術風格 (Art Nouveau)',
    '夏克風格 (Shaker Style)',
    '後現代主義 (Postmodernism)'
  ], []);
  const masterArchitects = useMemo(() => [
    '札哈·哈蒂 (Zaha Hadid)',
    '法蘭克·蓋瑞 (Frank Gehry)',
    '安藤忠雄 (Tadao Ando)',
    '路康 (Louis Kahn)',
    '倫佐·皮亞諾 (Renzo Piano)',
    '諾曼·福斯特 (Norman Foster)',
    '貝聿銘 (I. M. Pei)',
    '柯比意 (Le Corbusier)',
    '密斯·凡德羅 (Mies van der Rohe)',
    '法蘭克·洛伊·萊特 (Frank Lloyd Wright)',
    '高第 (Antoni Gaudí)',
    '阿爾瓦·阿爾托 (Alvar Aalto)',
    '伊東豊雄 (Toyo Ito)',
    '妹島和世 (Kazuyo Sejima)',
    '王澍 (Wang Shu)',
    '聖地牙哥·卡拉特拉瓦 (Santiago Calatrava)',
    '奧斯卡·尼邁耶 (Oscar Niemeyer)',
    'BIG (Bjarke Ingels Group)',
    '丹下健三 (Kenzo Tange)',
    '彼得·卒姆托 (Peter Zumthor)',
    '理查·羅傑斯 (Richard Rogers)',
    '赫爾佐格和德梅隆 (Herzog & de Meuron)',
    '隈研吾 (Kengo Kuma)',
    '坂茂 (Shigeru Ban)',
    '大衛·奇普菲爾德 (David Chipperfield)'
  ], []);
  const buildingMaterials = useMemo(() => [
    '清水模混凝土 (Fair-faced Concrete)',
    '紅磚 (Red Brick)',
    '玻璃帷幕 (Glass Curtain Wall)',
    '木質飾板 (Wood Cladding)',
    '石材 (Stone)',
    '金屬面板 (Metal Panels)',
    '耐候鋼 (Corten Steel)',
    '白色灰泥 (White Stucco)',
    '再生木材 (Reclaimed Wood)',
    '鈦鋅板 (Zinc Panels)',
    '銅板 (Copper Panels)',
    '聚碳酸酯板 (Polycarbonate Sheeting)',
    '竹子 (Bamboo)',
    '燒杉 (Shou Sugi Ban)',
    '石灰岩 (Limestone)',
    '花崗岩 (Granite)',
    '大理石 (Marble)',
    '陶磚 (Terracotta Tiles)',
    '綠色植生牆 (Green Living Wall)',
    'U型玻璃 (U-Glass)'
  ], []);
  const viewAngles = useMemo(() => [
    '人視角 (A standard eye-level shot from the street)',
    '鳥瞰圖 (A high-angle "drone shot" looking down at the building and its roof)',
    '仰角透視 (A dramatic, low-angle "worm\'s-eye view" looking up at the facade)',
    '遠景 (A shot from a distance, showing the building within its surrounding context)',
    '建築細節特寫 (A close-up, artistic shot focusing on a specific architectural detail)',
    '黃昏斜角 (An angled shot during the golden hour to emphasize texture and shadows)',
    '街角透視 (A classic perspective shot from a street corner, showing two sides)',
    '入口特寫 (A welcoming, close-up view focused on the main entrance)',
    '屋頂視角 (A view from the rooftop, looking out at the surrounding area)',
    '窗戶特寫 (A detailed shot focusing on a single interesting window and its frame)',
    '夜間長曝 (A nighttime long-exposure shot, with light trails from traffic)',
    '水中倒影 (A view showing the building reflected in a calm body of water)',
    '廣角張力 (A wide-angle lens shot from up close to exaggerate scale and perspective)',
    '長焦壓縮 (A telephoto lens shot from far away, compressing the building against its background)',
    '日落剪影 (The silhouette of the building against a vibrant sunset sky)',
    '前景框架 (A view framed by foreground elements, like tree branches or an archway)',
    '立面正視圖 (A flat, architectural elevation-style photograph of the main facade)',
    '45度角 (A standard 45-degree angle axonometric-style view)',
    '雨中即景 (The building on a rainy day, with reflections on wet pavement and a moody atmosphere)',
    '雪中即景 (The building and its surroundings covered in a peaceful blanket of snow)',
    '半空中視角 (Mezzanine-level view)',
    '透過窗戶 (Looking in from through a window)',
    '魚眼鏡頭 (Fisheye lens perspective)'
  ], []);
  const representationStyles = useMemo(() => [
    '藍晒圖 (Blueprint Style)',
    '水彩畫 (Watercolor Painting)',
    '彩色建築模型 (Colored Architectural Model)',
    '白色建築素模 (White Clay Model)',
    '立面圖 (Architectural Elevation Drawing)',
    '鉛筆素描 (Pencil Sketch)',
    '鋼筆畫 (Pen and Ink Drawing)',
    '麥克筆手繪 (Marker Rendering)',
    '樂高模型 (LEGO Model)',
    '像素藝術 (Pixel Art)',
    '3D 線框圖 (3D Wireframe)',
    '霓虹燈風格 (Neon Light Style)',
    '黏土模型 (Stop-motion Clay Model)',
    '木製模型 (Wooden Model)',
    '剪紙藝術 (Paper Cutout Art)',
    '電影海報風格 (Dramatic Movie Poster)',
    '復古照片 (Vintage Photograph)',
    '漫畫風格 (Comic Book Style)',
    '油畫 (Oil Painting)',
    '粉彩畫 (Pastel Drawing)',
    '移軸攝影 (Tilt-Shift Photography)',
    '點畫 (Pointillism)'
  ], []);
  const technicalDrawingStyles = useMemo(() => [
    { id: '正向立面圖', base: 'Draw a precise Front Elevation (Facade) of the building. Flat 2D view, technical line drawing, no perspective.' },
    { id: '背向立面圖', base: 'Draw a Rear Elevation of the building. Flat 2D view, technical line drawing.' },
    { id: '左側立面圖', base: 'Draw a Left Side Elevation of the building. Flat 2D view, technical line drawing.' },
    { id: '右側立面圖', base: 'Draw a Right Side Elevation of the building. Flat 2D view, technical line drawing.' },
    { id: '全區配置圖', base: 'Draw a Site Plan showing the building roof and its relationship to the surrounding site boundaries and roads. Top-down 2D view.' },
    { id: '一樓平面圖', base: 'Draw a Ground Floor Plan. Top-down 2D cut showing walls, doors, windows, and layout.' },
    { id: '二樓平面圖', base: 'Draw a Second Floor Plan. Top-down 2D cut showing the layout of the upper level.' },
    { id: '標準層平面圖', base: 'Draw a Typical Floor Plan used for multi-story sections of the building.' },
    { id: '屋頂平面圖', base: 'Draw a Roof Plan showing drainage, parapets, and roof textures. Top-down 2D view.' },
    { id: '地下室平面圖', base: 'Draw a Basement Plan showing parking or storage layout and structural columns.' },
    { id: '縱剖面圖', base: 'Draw a Longitudinal Section cutting through the long axis of the building. Show floor heights and interior structure.' },
    { id: '橫剖面圖', base: 'Draw a Cross Section cutting through the short axis of the building.' },
    { id: '透視剖面圖', base: 'Draw a Perspective Section (Sectional Perspective) showing both the cut structure and the depth of the interior space.' },
    { id: '爆炸圖', base: 'Draw an Exploded Axonometric diagram showing how the building parts (roof, floors, structure) fit together.' },
    { id: '結構分析圖', base: 'Draw a Structural Diagram highlighting columns, beams, and load-bearing walls in a schematic style.' },
    { id: '外牆剖面詳圖', base: 'Draw a detailed Wall Section (Facade Detail) showing the construction layers of the exterior wall.' },
    { id: '樓梯細部圖', base: 'Draw a Staircase Detail plan and section showing treads, risers, and railings.' },
    { id: '門窗大樣圖', base: 'Draw a Window/Door Schedule diagram showing the types and dimensions of openings.' },
    { id: '天花板反射圖', base: 'Draw a Reflected Ceiling Plan (RCP) showing lighting layout and ceiling patterns.' },
    { id: '消防逃生圖', base: 'Draw a Fire Evacuation Plan showing the building layout with arrows indicating escape routes.' },
    { id: '等角透視圖', base: 'Draw an Isometric or Axonometric projection of the building. Technical 3D line drawing.' }
  ], []);
  const landscapeStyles = useMemo(() => [
    { id: '日式禪意庭園', base: 'Design a Japanese Zen garden around the building with raked gravel, moss, and stone lanterns.' },
    { id: '英式鄉村花園', base: 'Create a lush English cottage garden with abundant flowers and winding paths.' },
    { id: '現代極簡景觀', base: 'Add a modern, minimalist landscape with geometric planting beds and ornamental grasses.' },
    { id: '熱帶雨林風格', base: 'Surround the building with a tropical rainforest landscape featuring large palm trees and ferns.' },
    { id: '沙漠耐旱景觀', base: 'Design a xeriscape garden with succulents, cacti, and decorative rocks.' },
    { id: '自然野趣林地', base: 'Create a natural, wild-looking woodland setting around the building.' },
    { id: '法式幾何庭園', base: 'Design a formal French garden with symmetrical hedges, fountains, and manicured lawns.' },
    { id: '地中海式庭院', base: 'Create a Mediterranean courtyard with terracotta pots, citrus trees, and lavender.' },
    { id: '垂直綠化植生牆', base: 'Cover parts of the building facade with a lush vertical green wall (living wall).' },
    { id: '空中花園', base: 'Transform the roof or balconies into a lush rooftop garden paradise.' },
    { id: '峇里島度假風', base: 'Create a Bali resort-style landscape with frangipani trees and a relaxing water feature.' },
    { id: '櫻花林步道', base: 'Surround the building with blooming pink cherry blossom trees.' },
    { id: '竹林幽徑', base: 'Plant a dense bamboo grove around the building for privacy and zen vibes.' },
    { id: '松林景觀', base: 'Place the building in a serene pine forest setting.' },
    { id: '普羅旺斯薰衣草', base: 'Surround the building with vast fields of purple lavender.' },
    { id: '玫瑰花園', base: 'Create a romantic garden filled with various colors of blooming roses.' },
    { id: '多肉植物園', base: 'Design a detailed garden focusing on various shapes and colors of succulents.' },
    { id: '水景荷花池', base: 'Add a large, calm water feature with lotus flowers and lily pads in front of the building.' },
    { id: '枯山水', base: 'Create a traditional dry landscape garden with arranged rocks and raked sand.' },
    { id: '現代雕塑公園', base: 'Place contemporary art sculptures within a manicured lawn setting around the building.' }
  ], []);
  const lightingStyles = useMemo(() => [
    { id: '溫暖光暈', base: 'Create a warm and inviting lighting scheme using soft, golden uplighting on the facade.' },
    { id: '現代冷光', base: 'Design a modern and sleek lighting plan with cool white or blue linear LED lights highlighting architectural lines.' },
    { id: '戲劇性光影', base: 'Use dramatic spotlights to create high contrast shadows and highlight specific textures or structural elements.' },
    { id: '彩色氛圍', base: 'Implement a dynamic colored lighting system (RGBW) that can wash the building in vibrant hues.' },
    { id: '低調典雅', base: 'Design a subtle and elegant lighting scheme with low-level landscape lighting and gentle washes on walls.' },
    { id: '節慶燈飾', base: 'Decorate the building with festive, sparkling string lights for a holiday atmosphere.' },
    { id: '賽博龐克霓虹', base: 'Add Cyberpunk style neon signage and strip lights in pink and cyan.' },
    { id: '建築輪廓光', base: 'Trace the edges of the building geometry with continuous LED strip lighting.' },
    { id: '泛光照明', base: 'Wash the entire facade with bright, even floodlights to showcase the building at night.' },
    { id: '剪影背光', base: 'Light the building from behind or inside to create a dramatic silhouette effect against the night sky.' },
    { id: '地面引導光', base: 'Focus on lighting the pathways and ground texture leading up to the building.' },
    { id: '燈籠微光', base: 'Use warm, glowing lanterns hanging or placed around the building for a cozy feel.' },
    { id: '藝術投影', base: 'Project artistic patterns or textures onto the building facade using projection mapping.' },
    { id: '星空倒影', base: 'Ensure the lighting interacts with a wet surface or water feature to create reflections of the building and stars.' },
    { id: '燭光氛圍', base: 'Simulate the flickering, warm glow of hundreds of candles around the building base.' },
    { id: '櫥窗焦點', base: 'Focus lighting intensely on the windows or entrance, leaving the rest of the building in mystery.' },
    { id: '工業琥珀光', base: 'Use vintage industrial style lighting with a deep amber/orange glow.' },
    { id: '柔和月光模擬', base: 'Simulate a bright full moon casting cool, silvery light over the building.' },
    { id: '點點螢火', base: 'Create a magical atmosphere with tiny fairy lights suspended in the air like fireflies.' },
    { id: '漸層色彩', base: 'Wash the facade with a smooth color gradient lighting effect (e.g., purple to blue).' }
  ], []);
  const environmentStyles = useMemo(() => [
    { id: '繁華市中心', base: 'Place the building in a bustling, dense city center with skyscrapers.' },
    { id: '寧靜郊區', base: 'Set the building in a quiet suburban neighborhood with green lawns.' },
    { id: '森林秘境', base: 'Integrate the building into a lush, dense forest environment.' },
    { id: '濱海懸崖', base: 'Position the building on a dramatic coastal cliff overlooking the ocean.' },
    { id: '沙漠綠洲', base: 'Place the building in a stark, beautiful desert landscape.' },
    { id: '未來都市', base: 'Render the building within a futuristic, high-tech cityscape.' },
    { id: '雪山腳下', base: 'Place the building at the base of a majestic, snow-capped mountain range.' },
    { id: '熱帶島嶼', base: 'Set the building on a white sand beach of a tropical island with turquoise water.' },
    { id: '月球表面', base: 'Imagine the building situated on the cratered, gray surface of the moon with Earth in the sky.' },
    { id: '海底世界', base: 'Place the building inside a glass dome under the ocean, surrounded by marine life.' },
    { id: '火星基地', base: 'Set the building on the red, dusty terrain of Mars.' },
    { id: '天空之城', base: 'Place the building on a floating island in the sky, surrounded by clouds.' },
    { id: '中世紀村莊', base: 'Integrate the building into a cobblestoned, historic medieval village.' },
    { id: '廢墟工業區', base: 'Place the building in a gritty, abandoned industrial district with overgrown vegetation.' },
    { id: '稻田田園', base: 'Set the building in the middle of lush green terraced rice paddies.' },
    { id: '繽紛花海', base: 'Surround the building with an endless field of colorful wildflowers.' },
    { id: '秋日公園', base: 'Place the building in a park filled with trees showing vibrant orange and red autumn leaves.' },
    { id: '雨夜街道', base: 'Set the building on a wet, reflective street in a rainy city at night (Cyberpunk vibe).' },
    { id: '瑞士阿爾卑斯', base: 'Place the building in a green alpine meadow with mountains in the background.' },
    { id: '大峽谷', base: 'Position the building on the edge of the Grand Canyon.' }
  ], []);
  const weatherStyles = useMemo(() => [
    { id: '清晨', base: 'Early morning with soft, cool light and long shadows.' },
    { id: '艷陽高照', base: 'Bright noon daylight with harsh shadows and clear blue sky.' },
    { id: '午後斜陽', base: 'Warm afternoon sunlight creating a cozy atmosphere.' },
    { id: '魔幻時刻', base: 'Golden hour lighting, just before sunset, with warm, soft hues.' },
    { id: '傍晚藍調', base: 'Blue hour dusk, just after sunset, with a deep blue sky and city lights turning on.' },
    { id: '深夜星空', base: 'Clear night sky filled with stars, very little artificial light.' },
    { id: '陰天柔光', base: 'Overcast sky providing soft, diffused, shadowless light.' },
    { id: '滂沱大雨', base: 'Heavy rainstorm with dark clouds, wet surfaces, and rain streaks.' },
    { id: '濛濛細雨', base: 'Light drizzle, creating a soft, moody, and slightly misty atmosphere.' },
    { id: '暴風雨前夕', base: 'Dramatic, dark, ominous clouds gathering before a storm.' },
    { id: '漫天大雪', base: 'Heavy snowfall, whiteout conditions, snowflakes in the air.' },
    { id: '積雪初晴', base: 'Sunny clear day after a snowstorm, with fresh white snow on the ground.' },
    { id: '濃霧瀰漫', base: 'Thick fog or mist surrounding the building, creating a mysterious vibe.' },
    { id: '強風吹拂', base: 'Windy weather, trees bending, leaves blowing, dynamic atmosphere.' },
    { id: '冰雹天氣', base: 'Cold, icy atmosphere with hail on the ground.' },
    { id: '彩虹跨越', base: 'Just after rain, with a bright double rainbow in the sky behind the building.' },
    { id: '極光天空', base: 'Night time with vibrant green and purple Aurora Borealis in the sky.' },
    { id: '閃電劃過', base: 'Night storm with a dramatic lightning bolt striking in the background.' },
    { id: '霧霾朦朧', base: 'Hazy, polluted sunset creating a diffused orange/red light.' },
    { id: '颱風過境', base: 'Chaotic, wet, and windy typhoon weather conditions.' }
  ], []);

  // Function to get N random unique items from an array
  const getRandomItems = (arr, n) => {
    const shuffled = [...arr].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, n);
  };

  const templates = useMemo(() => ({
    lineDraftToReal: {
      name: '線稿寫實',
      description: '將建築設計草圖轉為真實照片。',
      icon: '📐',
      isRandom: true,
      styleSource: architecturalStyles,
    },
    masterDesign: {
      name: '大師設計',
      description: '模擬世界知名建築大師的風格。',
      icon: '🏛️',
      isRandom: true,
      styleSource: masterArchitects,
    },
    materialFacadeChange: {
      name: '立面換裝',
      description: '為您的建築變換外牆材質。',
      icon: '🧱',
      isRandom: true,
      styleSource: buildingMaterials,
    },
    technicalDrawing: {
      name: '立面圖說',
      description: '生成立面、剖面、平面等專業建築圖。',
      icon: '📐',
      isRandom: true,
      styleSource: technicalDrawingStyles,
    },
    fullStyleChange: {
      name: '風格呈現',
      description: '將建築轉換為不同的藝術表現形式。',
      icon: '🖼️',
      isRandom: true,
      styleSource: representationStyles,
    },
    environmentChange: {
      name: '環境融合',
      description: '預覽建築在不同環境中的樣貌。',
      icon: '🏞️',
      isRandom: true,
      styleSource: environmentStyles,
    },
    dayNightChange: {
      name: '天候光影',
      description: '預覽建築在不同天氣與時間的光影。',
      icon: '🌦️',
      isRandom: true,
      styleSource: weatherStyles,
    },
    addLandscaping: {
      name: '景觀設計',
      description: '為您的建築添加周邊綠化造景。',
      icon: '🌳',
      isRandom: true,
      styleSource: landscapeStyles,
    },
    viewAngleChange: {
      name: '視角預覽',
      description: '從不同角度查看您的建築設計。',
      icon: '📷',
      isRandom: true,
      styleSource: viewAngles,
    },
    lightingPlan: {
      name: '夜間照明計畫',
      description: '預覽不同的建築夜間燈光設計。',
      icon: '💡',
      isRandom: true,
      styleSource: lightingStyles,
    },
  }), [architecturalStyles, buildingMaterials, masterArchitects, viewAngles, representationStyles, environmentStyles, weatherStyles, landscapeStyles, lightingStyles, technicalDrawingStyles]);

  const regenerateImageAtIndex = async (imageIndex) => {
    const imageToRegenerate = generatedImages[imageIndex];
    if (!imageToRegenerate || !template) return;

    setGeneratedImages(prev => prev.map((img, index) =>
      index === imageIndex ? { ...img, status: 'pending' } : img
    ));
    setError(null);

    const activeTemplate = templates[template];
    // The prompt is already stored in the generatedImages state object
    const prompt = { id: imageToRegenerate.id, base: imageToRegenerate.base };

    if (!prompt) {
      setError("找不到重新生成所需的提示。");
      setGeneratedImages(prev => prev.map((img, index) => index === imageIndex ? { ...img, status: 'failed' } : img));
      return;
    }

    try {
      const imageWithoutPrefix = uploadedImage.split(',')[1];
      // Get correct mime type dynamically
      const mimeType = uploadedImage.match(/[^:]\w+\/[\w-+\d.]+(?=;|,)/)?.[0] || "image/png";

      const modelInstruction = getModelInstruction(template, prompt, {});

      const payload = {
        contents: [{
          parts: [
            { text: modelInstruction },
            { inlineData: { mimeType: mimeType, data: imageWithoutPrefix } }
          ]
        }],
        generationConfig: {
          responseModalities: ["TEXT", "IMAGE"]
        }
      };

      const imageUrl = await generateImageWithRetry(payload);

      setGeneratedImages(prev => prev.map((img, index) =>
        index === imageIndex ? { ...img, status: 'success', imageUrl } : img
      ));

    } catch (err) {
      console.error(`Regeneration failed for ${prompt.id}:`, err);
      setError(`唉呀！為 "${prompt.id}" 重新生成失敗了。請再試一次。`);
      setGeneratedImages(prev => prev.map((img, index) =>
        index === imageIndex ? { ...img, status: 'failed' } : img
      ));
    }
  };

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setIsUploading(true);
      setError(null);
      try {
        const base64Image = await toBase64(file);
        setUploadedImage(base64Image);
        setGeneratedImages([]);
      } catch (err) {
        console.error("Error during image upload:", err);
        setError("無法處理此圖片。請嘗試其他檔案。");
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleCaptureConfirm = (imageDataUrl) => {
    setUploadedImage(imageDataUrl);
    setGeneratedImages([]);
    setError(null);
  };

  const handleGenerateClick = async () => {
    if (!uploadedImage) {
      setError("請先上傳一張照片！");
      return;
    }
    if (!template) {
      setError("請選擇一個功能主題！");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedImages([]);

    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    const imageWithoutPrefix = uploadedImage.split(',')[1];
    // Get correct mime type dynamically
    const mimeType = uploadedImage.match(/[^:]\w+\/[\w-+\d.]+(?=;|,)/)?.[0] || "image/png";

    const activeTemplate = templates[template];

    let promptsForGeneration = [];
    if (activeTemplate.isRandom) {
      const randomStyles = getRandomItems(activeTemplate.styleSource, 6);
      promptsForGeneration = randomStyles.map(style => {
        // Handle both string styles (like architectural styles) and object styles (like weather)
        if (typeof style === 'string') {
          return { id: style, base: style };
        }
        return style; // Assume it is already { id, base } object
      });
    } else {
      promptsForGeneration = activeTemplate.prompts;
    }

    if (!promptsForGeneration || promptsForGeneration.length === 0) {
      setError("準備創意點子時發生錯誤，請重試。");
      setIsLoading(false);
      return;
    }

    const initialPlaceholders = promptsForGeneration.map(p => ({
      id: p.id,
      base: p.base, // Store the base prompt for regeneration
      status: 'pending',
      imageUrl: null,
    }));
    setGeneratedImages(initialPlaceholders);

    for (let i = 0; i < promptsForGeneration.length; i++) {
      const p = promptsForGeneration[i];
      try {
        const modelInstruction = getModelInstruction(template, p, {});

        const payload = {
          contents: [{
            parts: [
              { text: modelInstruction },
              { inlineData: { mimeType: mimeType, data: imageWithoutPrefix } }
            ]
          }],
          generationConfig: {
            responseModalities: ["TEXT", "IMAGE"]
          }
        };

        const imageUrl = await generateImageWithRetry(payload);

        setGeneratedImages(prev => prev.map((img, index) =>
          index === i ? { ...img, status: 'success', imageUrl } : img
        ));

      } catch (err) {
        console.error(`Failed to generate image for ${p.id} after all retries:`, err);
        setGeneratedImages(prev => prev.map((img, index) =>
          index === i ? { ...img, status: 'failed' } : img
        ));
      }
    }

    setIsLoading(false);
  };

  const triggerDownload = async (href, fileName) => {
    try {
      const response = await fetch(href);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch (error) {
      console.error("Could not download the image:", error);
      setError("抱歉，下載失敗。請重試。");
    }
  };

  const handleDownloadRequest = async (imageUrl, era, ratio, size = null) => {
    const sizeString = size ? `${size.width}x${size.height}` : ratio.replace(':', 'x');
    const fileName = `建築外觀精靈-${era.toLowerCase().replace(/\s+/g, '-')}-${sizeString}.png`;
    try {
      const framedImageUrl = await createSingleFramedImage(imageUrl, ratio, era, size);
      await triggerDownload(framedImageUrl, fileName);
    } catch (err) {
      console.error(`Failed to create framed image for download:`, err);
      setError(`無法準備該圖片進行下載，請重試。`);
    }
  };


  const handleAlbumDownloadRequest = async (ratio, outputSize = null) => {
    if (isDownloadingAlbum) return;
    setIsDownloadingAlbum(true);
    setError(null);

    try {
      const successfulImages = generatedImages.filter(img => img.status === 'success');
      if (successfulImages.length === 0) {
        setError("沒有成功的圖片可以打包成作品集。");
        setIsDownloadingAlbum(false);
        return;
      }

      let albumTitle = "我的建築設計作品集";
      if (template && templates[template]) {
        albumTitle = `設計作品集: ${templates[template].name}`;
      }

      const croppedImageUrls = await Promise.all(
        successfulImages.map(img => cropImage(img.imageUrl, ratio))
      );

      const imagesToStitch = await Promise.all(
        croppedImageUrls.map((url, index) => new Promise((resolve, reject) => {
          const img = new Image();
          img.crossOrigin = "anonymous";
          img.src = url;
          img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            let targetWidth = img.width;
            let targetHeight = img.height;
            if (outputSize) {
              const maxWidth = 1024; // 為避免最終圖片過大，限制作品集中的圖片寬度
              if (outputSize.width > maxWidth) {
                const scale = maxWidth / outputSize.width;
                targetWidth = maxWidth;
                targetHeight = Math.round(outputSize.height * scale);
              } else {
                targetWidth = outputSize.width;
                targetHeight = outputSize.height;
              }
            }

            const bottomPadding = targetWidth * 0.14;
            canvas.width = targetWidth;
            canvas.height = targetHeight + bottomPadding;

            ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

            const labelFontSize = Math.max(24, Math.floor(targetWidth * 0.08));
            ctx.font = `700 ${labelFontSize}px "Noto Sans TC", sans-serif`;
            ctx.fillStyle = "rgba(0, 0, 0, 0.8)";
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(successfulImages[index].id, canvas.width / 2, targetHeight + bottomPadding / 2);

            const finalImage = new Image();
            finalImage.crossOrigin = "anonymous";
            finalImage.src = canvas.toDataURL('image/png');
            finalImage.onload = () => resolve(finalImage);
            finalImage.onerror = reject;
          };
          img.onerror = reject;
        }))
      );

      if (imagesToStitch.length === 0) throw new Error("沒有圖片可建立作品集。");

      const stitchCanvas = document.createElement('canvas');
      const stitchCtx = stitchCanvas.getContext('2d');

      const cols = imagesToStitch.length > 4 ? 3 : 2;
      const rows = Math.ceil(imagesToStitch.length / cols);
      const imageWidth = imagesToStitch[0].width;
      const imageHeight = imagesToStitch[0].height;
      const padding = Math.floor(imageWidth * 0.05);

      stitchCanvas.width = (cols * imageWidth) + ((cols + 1) * padding);
      stitchCanvas.height = (rows * imageHeight) + ((rows + 1) * padding);

      stitchCtx.fillStyle = '#FFFFFF';
      stitchCtx.fillRect(0, 0, stitchCanvas.width, stitchCanvas.height);

      imagesToStitch.forEach((img, index) => {
        const row = Math.floor(index / cols);
        const col = index % cols;
        stitchCtx.drawImage(img, padding + col * (imageWidth + padding), padding + row * (imageHeight + padding), imageWidth, imageHeight);
      });

      const finalCanvas = document.createElement('canvas');
      const finalCtx = finalCanvas.getContext('2d');

      const outerPadding = stitchCanvas.width * 0.05;
      const titleFontSize = Math.max(48, Math.floor(stitchCanvas.width * 0.07));
      const footerFontSize = Math.max(24, Math.floor(stitchCanvas.width * 0.025));
      const titleSpacing = titleFontSize * 1.5;
      const footerSpacing = footerFontSize * 2;

      finalCanvas.width = stitchCanvas.width + outerPadding * 2;
      finalCanvas.height = stitchCanvas.height + outerPadding * 2 + titleSpacing + footerSpacing;

      finalCtx.fillStyle = '#111827';
      finalCtx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);

      finalCtx.font = `700 ${titleFontSize}px "Noto Sans TC", sans-serif`;
      finalCtx.fillStyle = "rgba(255, 255, 255, 0.9)";
      finalCtx.textAlign = 'center';
      finalCtx.textBaseline = 'middle';
      finalCtx.fillText(albumTitle, finalCanvas.width / 2, outerPadding + titleSpacing / 2);

      finalCtx.drawImage(stitchCanvas, outerPadding, outerPadding + titleSpacing);

      finalCtx.font = `600 ${footerFontSize}px "Noto Sans TC", sans-serif`;
      finalCtx.fillStyle = "rgba(255, 255, 255, 0.5)";
      finalCtx.textAlign = 'center';
      finalCtx.textBaseline = 'middle';
      finalCtx.fillText("由 Gemini 生成", finalCanvas.width / 2, finalCanvas.height - (footerSpacing / 2));

      const sizeString = outputSize ? `${outputSize.width}x${outputSize.height}` : ratio.replace(':', 'x');
      await triggerDownload(finalCanvas.toDataURL('image/png'), `建築設計作品集-${sizeString}.png`);
    } catch (err) {
      console.error("Failed to create or download album:", err);
      setError("抱歉，作品集下載失敗。請重試。");
    } finally {
      setIsDownloadingAlbum(false);
    }
  };

  const handleZipDownload = async () => {
    if (isZipping) return;

    setIsZipping(true);
    setError(null);

    try {
      const successfulImages = generatedImages.filter(img => img.status === 'success');
      if (successfulImages.length === 0) {
        setError("沒有成功的圖片可以下載。");
        setIsZipping(false);
        return;
      }

      const zip = new JSZip();

      const imagePromises = successfulImages.map(async (img, index) => {
        const response = await fetch(img.imageUrl);
        if (!response.ok) {
          throw new Error(`Failed to fetch image: ${img.imageUrl}`);
        }
        const blob = await response.blob();
        const fileName = `設計-${index + 1}-${img.id.replace(/[\\/:"*?<>|()\s]/g, '')}.png`;
        zip.file(fileName, blob);
      });

      await Promise.all(imagePromises);

      const content = await zip.generateAsync({ type: "blob" });

      const link = document.createElement("a");
      link.href = URL.createObjectURL(content);
      link.download = "建築設計作品集.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);

    } catch (err) {
      console.error("Failed to create or download zip:", err);
      setError("抱歉，建立 ZIP 壓縮檔失敗。請重試。");
    } finally {
      setIsZipping(false);
    }
  };

  const handleStartOver = () => {
    setGeneratedImages([]);
    setUploadedImage(null);
    setError(null);
    setTemplate(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };


  const AlbumDownloadButton = () => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef(null);

    useEffect(() => {
      const handleClickOutside = (event) => {
        if (menuRef.current && !menuRef.current.contains(event.target)) {
          setIsOpen(false);
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [menuRef]);

    const handleButtonClick = () => {
      setIsOpen(!isOpen);
    };

    return (
      <div className="relative" ref={menuRef}>
        <Button primary disabled={isDownloadingAlbum} onClick={handleButtonClick}>
          {isDownloadingAlbum ? (
            <div className="flex items-center justify-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-black"></div>
              <span>準備中...</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <IconDownload />
              <span>下載作品集</span>
            </div>
          )}
        </Button>
        {isOpen && !isDownloadingAlbum && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.1 }}
            className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 z-20"
          >
            <div className="bg-black/80 backdrop-blur-lg rounded-xl text-white text-sm flex flex-col items-start p-1 shadow-2xl w-56 border border-gray-700">
              <button onClick={() => { handleAlbumDownloadRequest('1:1'); setIsOpen(false); }} className="w-full text-left px-4 py-2 hover:bg-yellow-400/20 rounded-lg transition-colors">正方形 (1:1)</button>
              <button onClick={() => { handleAlbumDownloadRequest('9:16'); setIsOpen(false); }} className="w-full text-left px-4 py-2 hover:bg-yellow-400/20 rounded-lg transition-colors">直向 (9:16)</button>
              <button onClick={() => { handleAlbumDownloadRequest('1920:1400', { width: 1920, height: 1400 }); setIsOpen(false); }} className="w-full text-left px-4 py-2 hover:bg-yellow-400/20 rounded-lg transition-colors">高解析度 (1920x1400)</button>
            </div>
          </motion.div>
        )}
      </div>
    );
  };

  const progress = generatedImages.length > 0
    ? (generatedImages.filter(img => img.status !== 'pending').length / generatedImages.length) * 100
    : 0;

  return (
    <>
      <style>{`
              @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;500;700&display=swap');
              
              body { 
                font-family: 'Noto Sans TC', sans-serif; 
                background-color: #0c0a09;
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='150' height='150' viewBox='0 0 150 150'%3E%3Ctext x='50%25' y='50%25' font-family='Noto Sans TC, sans-serif' font-size='24' fill='%23ffffff' fill-opacity='0.08' text-anchor='middle' dominant-baseline='middle' transform='rotate(-45, 75, 75)'%3ECTA%3C/text%3E%3C/svg%3E");
              }
              .font-logo { font-family: 'Noto Sans TC', sans-serif; font-weight: 700; }
              
              @keyframes fade-in-down {
                0% { opacity: 0; transform: translateY(-20px); }
                100% { opacity: 1; transform: translateY(0); }
              }
              .animate-fade-in-down { animation: fade-in-down 0.5s ease-out forwards; }

               .styled-scrollbar::-webkit-scrollbar { width: 8px; }
               .styled-scrollbar::-webkit-scrollbar-track { background: #334155; border-radius: 10px; }
               .styled-scrollbar::-webkit-scrollbar-thumb { background: #64748B; border-radius: 10px; }
               .styled-scrollbar::-webkit-scrollbar-thumb:hover { background: #FBBF24; }
            `}</style>

      <CameraModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={handleCaptureConfirm}
      />

      <div className="bg-transparent text-gray-200 min-h-screen flex flex-col items-center p-4 pb-20">
        <ErrorNotification message={error} onDismiss={() => setError(null)} />

        <div className="w-full max-w-6xl mx-auto">

          <header className="text-center my-12">
            <h1 className="text-6xl md:text-7xl font-logo text-white">
              <span className="text-yellow-400">建築外觀</span>小精靈
            </h1>
            <p className="mt-4 text-lg text-gray-400">上傳您的建築照片或設計草圖，讓 Gemini AI 為您實現無限可能。</p>
          </header>

          <main>
            <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl shadow-2xl border border-gray-800 mb-16">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">

                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-white">1. 上傳您的照片</h2>
                  <div
                    className="w-full aspect-square border-4 border-dashed border-gray-700 rounded-xl flex items-center justify-center cursor-pointer hover:border-yellow-400 transition-colors bg-gray-800 overflow-hidden shadow-inner"
                    onClick={() => !uploadedImage && fileInputRef.current && fileInputRef.current.click()}
                  >
                    {isUploading ? (
                      <div className="flex flex-col items-center">
                        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-yellow-400 mb-4"></div>
                        <p className="text-gray-400 mt-4">上傳中...</p>
                      </div>
                    ) : uploadedImage ? (
                      <img src={uploadedImage} alt="已上傳預覽" className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex flex-col items-center justify-center p-6 text-center text-gray-500">
                        <IconUpload />
                        <p className="mt-4 text-lg text-gray-300">點擊此處上傳檔案</p>
                        <p className="mt-4 text-sm">或</p>
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsCameraOpen(true);
                          }}
                          className="mt-2"
                        >
                          <div className="flex items-center gap-2">
                            <IconCamera />
                            <span>使用相機</span>
                          </div>
                        </Button>
                      </div>
                    )}
                  </div>
                  {uploadedImage && !isUploading && (
                    <div className="flex flex-col sm:flex-row gap-4 mt-4 w-full">
                      <Button onClick={() => fileInputRef.current && fileInputRef.current.click()} className="flex-1">
                        更換檔案
                      </Button>
                      <Button onClick={() => setIsCameraOpen(true)} className="flex-1">
                        <div className="flex items-center justify-center gap-2">
                          <IconCamera />
                          <span>使用相機</span>
                        </div>
                      </Button>
                    </div>
                  )}
                  <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/png, image/jpeg" className="hidden" />
                </div>

                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-white">2. 選擇 AI 功能</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
                    {Object.entries(templates).map(([key, data]) => (
                      <TemplateCard
                        key={key}
                        id={key}
                        name={data.name}
                        icon={data.icon}
                        description={data.description}
                        isSelected={template === key}
                        onSelect={setTemplate}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-12 text-center">
                <Button
                  onClick={handleGenerateClick}
                  disabled={!uploadedImage || !template || isLoading || isUploading}
                  primary
                  className="text-lg px-12 py-4"
                >
                  <div className="flex items-center gap-3">
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-black"></div>
                        {`生成中... (${Math.round(progress)}%)`}
                      </>
                    ) : (
                      <>
                        <IconSparkles />
                        開始生成
                      </>
                    )}
                  </div>
                </Button>
              </div>
            </div>


            <div ref={resultsRef}>
              {(isLoading || generatedImages.length > 0) && (
                <div className="mt-16">
                  <h2 className="text-3xl font-bold text-white mb-8 text-center">您的 AI 設計成果</h2>

                  {isLoading && (
                    <div className="w-full max-w-4xl mx-auto mb-8 text-center">
                      <div className="bg-gray-800 rounded-full h-3 overflow-hidden shadow-md">
                        <motion.div
                          className="bg-yellow-400 h-3 rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                      <p className="text-gray-400 mt-4 text-sm">請保持此視窗開啟，直到圖片生成完畢。</p>
                    </div>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 mt-8">
                    {generatedImages.map((img, index) => {
                      const showLabel = true;

                      switch (img.status) {
                        case 'success':
                          return <PhotoDisplay
                            key={`${img.id}-${index}-success`}
                            era={img.id}
                            imageUrl={img.imageUrl}
                            onDownload={handleDownloadRequest}
                            onRegenerate={() => regenerateImageAtIndex(index)}
                            isPolaroid={false}
                            index={index}
                            showLabel={showLabel}
                          />;
                        case 'failed':
                          return <ErrorCard
                            key={`${img.id}-${index}-failed`}
                            era={img.id}
                            onRegenerate={() => regenerateImageAtIndex(index)}
                            showLabel={showLabel}
                          />;
                        case 'pending':
                        default:
                          return <LoadingCard
                            key={`${img.id}-${index}-pending`}
                            era={img.id}
                            showLabel={showLabel} />;
                      }
                    })}
                  </div>
                  <p className="text-center text-xs text-gray-600 mt-8">由 Gemini 生成</p>
                </div>
              )}

              {!isLoading && generatedImages.length > 0 && (
                <div className="text-center mt-16 mb-12 flex flex-wrap justify-center gap-6">
                  <Button onClick={handleStartOver}>重新開始</Button>
                  <AlbumDownloadButton />
                  <Button onClick={handleZipDownload} disabled={isZipping} className="bg-green-600 hover:bg-green-500 text-white border-green-700">
                    {isZipping ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                        <span>壓縮中...</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <IconDownload />
                        <span>下載 ZIP</span>
                      </div>
                    )}
                  </Button>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </>
  );
};

export default App;
